fx_version 'cerulean'
game 'gta5'

author 'BluNovaESX'
description 'BluNova HUD - Modernes ESX HUD (Legacy/Classic kompatibel)'
version '1.1.0'

ui_page 'html/index.html'

client_scripts {
    'client/main.lua'
}

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/script.js'
}

dependencies {
    'es_extended'
}